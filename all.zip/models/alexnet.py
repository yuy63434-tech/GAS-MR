import torch.nn as nn
from easyfl.models import BaseModel

class AlexNet(BaseModel):
    def __init__(self, num_classes=10):
        super(AlexNet, self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=11, stride=4, padding=5),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            nn.Conv2d(64, 192, kernel_size=5, padding=2),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            nn.Conv2d(192, 384, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(384, 256, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
        )
        self.classifier = nn.Linear(256, num_classes)

    def forward(self, x):
        x = self.features(x)
        x = x.view(x.size(0), -1)
        x = self.classifier(x)
        return x

def alexnet(**kwargs):
    model = AlexNet(**kwargs)
    return model
# class CIFAR10AlexNet(BaseModel):
#     def __init__(self, num_class=10):
#         super(CIFAR10AlexNet, self).__init__()
#         # 特别适配 CIFAR-10 32x32 图像
#         self.features = nn.Sequential(
#             nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1),  # conv1
#             nn.ReLU(inplace=True),
#             nn.MaxPool2d(kernel_size=2, stride=2),                  # 16x16
#
#             nn.Conv2d(64, 192, kernel_size=3, padding=1),           # conv2
#             nn.ReLU(inplace=True),
#             nn.MaxPool2d(kernel_size=2, stride=2),                  # 8x8
#
#             nn.Conv2d(192, 384, kernel_size=3, padding=1),          # conv3
#             nn.ReLU(inplace=True),
#
#             nn.Conv2d(384, 256, kernel_size=3, padding=1),          # conv4
#             nn.ReLU(inplace=True),
#
#             nn.Conv2d(256, 256, kernel_size=3, padding=1),          # conv5
#             nn.ReLU(inplace=True),
#             nn.MaxPool2d(kernel_size=2, stride=2),                  # 4x4
#         )
#
#         self.classifier = nn.Sequential(
#             nn.Dropout(0.5),
#             nn.Linear(256*4*4, 1024),
#             nn.ReLU(inplace=True),
#             nn.Dropout(0.5),
#             nn.Linear(1024, 512),
#             nn.ReLU(inplace=True),
#             nn.Linear(512, num_class)
#         )
#
#         self._initialize_weights()
#
#     def forward(self, x):
#         x = self.features(x)
#         x = x.view(x.size(0), 256*4*4)
#         x = self.classifier(x)
#         return x
#
#     def _initialize_weights(self):
#         for m in self.modules():
#             if isinstance(m, nn.Conv2d):
#                 nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
#                 if m.bias is not None:
#                     nn.init.constant_(m.bias, 0)
#             elif isinstance(m, nn.Linear):
#                 nn.init.kaiming_uniform_(m.weight, a=1)
#                 nn.init.constant_(m.bias, 0)