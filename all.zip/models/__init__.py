from .alexnet import AlexNet


__all__ = ['AlexNet']  # 添加 CNN 到导出列表
