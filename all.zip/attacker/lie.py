from __future__ import annotations

import numpy as np
import torch


from utils import flatten_models, unflatten_tensor
from .base import Attacker


class Lie(Attacker):
            def attack(self, sampled_clients: list, server):
                    benign_clients = [c for c in sampled_clients if not c.is_byz]
                    n_good = len(benign_clients)
                    assert n_good > 0, "No benign clients for LIE attack"
                    ref_models = self.get_ref_models(benign_clients)
                    flat_models, struct = flatten_models(ref_models)
                    mu = flat_models.mean(dim=0)
                    std = flat_models.std(dim=0, unbiased=False)
                    z = 1.5
                    flat_byz_model = mu - z * std
                    byz_state_dict = unflatten_tensor(flat_byz_model, struct)
                    self.set_byz_uploaded_content(sampled_clients, byz_state_dict, server)

