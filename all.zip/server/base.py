from __future__ import annotations
import copy
import time
import numpy as np
import torch
import os

from argparse import Namespace
from easyfl.server import BaseServer
from easyfl.server.base import MODEL, DATA_SIZE
from easyfl.tracking import metric
from easyfl.utils.float import rounding
from math import ceil
from omegaconf import OmegaConf
from rsa import PrivateKey


from attacker import Lie
from client import CustomizedClient
import os
import numpy as np

import copy
from types import SimpleNamespace as Namespace
from utils import flatten_models, unflatten_tensor
from .agg_funs import agg_funs
import argparse
import concurrent.futures
import copy
import logging
import os
import threading
import time

import numpy as np
import torch
import torch.distributed as dist
from omegaconf import OmegaConf

from easyfl.communication import grpc_wrapper
from easyfl.datasets import TEST_IN_SERVER
from easyfl.distributed import grouping, reduce_models, reduce_models_only_params, \
    reduce_value, reduce_values, reduce_weighted_values, gather_value
from easyfl.distributed.distributed import CPU, GREEDY_GROUPING
from easyfl.pb import client_service_pb2 as client_pb
from easyfl.pb import common_pb2 as common_pb
from easyfl.protocol import codec
from easyfl.registry.etcd_client import EtcdClient
from easyfl.server import strategies
from easyfl.server.service import ServerService
from easyfl.tracking import metric
from easyfl.tracking.client import init_tracking
from easyfl.utils.float import rounding

class RobustServer(BaseServer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 添加统计变量
        self.total_selected_byz = 0  # 总共选中的拜占庭客户端数
        self.total_rejected_byz = 0  # 总共剔除的拜占庭客户端数
        self.total_aggregated_byz = 0  # 总共参与聚合的拜占庭客户端数

    def reset_statistics(self):
        """重置统计计数器"""
        self.total_selected_byz = 0
        self.total_rejected_byz = 0
        self.total_aggregated_byz = 0
    def generate_filename(self):
        """根据当前配置生成唯一的文件名"""
        attack_type = getattr(self.conf.attacker, 'type', 'unknown')
        base_agg = getattr(self.conf.server, 'base_agg', 'unknown')
        use_gas = getattr(self.conf.server, 'use_gas', False)
        use_gas_mr = getattr(self.conf.server, 'use_gas_mr', False)

        # 构建文件名
        filename_parts = [
            "acc_curve",
            f"attack_{attack_type}",
            f"agg_{base_agg}",
            f"gas_{use_gas}",
            f"highvar_{use_high_variance}"
        ]

        filename = "_".join(filename_parts) + ".npy"
        return filename

    def start(self, model, clients):
        """Start federated learning process, including training and testing.

        Args:
            model (nn.Module): The model to train.
            clients (list[:obj:`BaseClient`]|list[str]): Available clients.
                Clients are actually client grpc addresses when in remote training.
        """
        # Setup
        self._start_time = time.time()
        self._reset()
        self.set_model(model)
        self.set_clients(clients)
        # 初始化统计变量
        self.reset_statistics()
        # customize
        byz_clients = self.get_byz_clients(clients)
        # 根据配置选择攻击类型
        attack_type = self.conf.attacker.type if hasattr(self.conf.attacker, 'type') else 'lie'

        if attack_type == 'lie':
            self.attacker = Lie(self.conf, byz_clients)
        elif attack_type == 'minmax':
            self.attacker = MinMax(self.conf, byz_clients)
        elif attack_type == 'minsum':
            self.attacker = MinSum(self.conf, byz_clients)
        elif attack_type == 'bitflip':
            self.attacker = BitFlip(self.conf, byz_clients)
        elif attack_type == 'labelflip':
            self.attacker = LabelFlip(self.conf, byz_clients)
        elif attack_type == 'ipm':
            self.attacker = IPM(self.conf, byz_clients)
        elif attack_type == 'trim':
            self.attacker = TrimAttack(self.conf, byz_clients)
        else:
            raise ValueError(f"Unknown attack type: {attack_type}")

        if self._should_track():
            self._tracker.create_task(self.conf.task_id, OmegaConf.to_container(self.conf))

        # Get initial testing accuracies
        if self.conf.server.test_all:
            if self._should_track():
                self._tracker.set_round(self._current_round)
            self.test()
            self.save_tracker()

        while not self.should_stop():
            self._round_time = time.time()

            self._current_round += 1
            self.print_("\n-------- round {} --------".format(self._current_round))

            # Train
            self.pre_train()
            self.train()

            self.post_train()

            # Test
            if self._do_every(self.conf.server.test_every, self._current_round, self.conf.server.rounds):
                self.pre_test()
                self.test()
                self.post_test()

            # Save Model
            self.save_model()

            self.track(metric.ROUND_TIME, time.time() - self._round_time)
            self.save_tracker()
            # 输出最终统计
        self.print_(f"\n=== FINAL STATISTICS ===")
        self.print_(f"Total rounds: {self._current_round}")
        self.print_(f"Total selected byzantine clients: {self.total_selected_byz}")
        self.print_(f"Total rejected byzantine clients: {self.total_rejected_byz}")
        self.print_(f"Total aggregated byzantine clients: {self.total_aggregated_byz}")
        self.print_(f"Rejection rate: {self.total_rejected_byz / self.total_selected_byz * 100:.2f}% if any selected")

        self.print_("Accuracies111: {}".format(rounding(self._accuracies, 4)))
        self.print_("Cumulative training time: {}".format(rounding(self._cumulative_times, 2)))
        import numpy as np
        acc_curve = np.array(self._accuracies)
        # 生成动态文件名并保存
        filename = self.generate_filename()
        np.save(filename, acc_curve)


    def train(self):
        """Training process of federated learning."""
        self.print_("--- start training ---")

        # 记录训练前的模型参数
        before_train_params = {}
        for name, param in self._model.named_parameters():
            before_train_params[name] = param.clone().detach()

        self.selection(self._clients, self.conf.server.clients_per_round)
        self.grouping_for_distributed()
        self.compression()

        begin_train_time = time.time()
        self.distribution_to_train()
        end_train_time = time.time()
        train_time = end_train_time - begin_train_time
        self.print_("Honest client train time: {}".format(train_time))

        start_attack_time = time.time()
        self.attacker.attack(self.selected_clients, self)
        end_attack_time = time.time()
        attack_time = end_attack_time - start_attack_time
        self.print_("Byzantine client attack time: {}".format(attack_time))

        start_aggretate_time = time.time()
        self.aggregation()
        end_aggretate_time = time.time()
        aggregate_time = end_aggretate_time - start_aggretate_time
        self.print_("Aggregate time: {}".format(aggregate_time))

        self.track(metric.TRAIN_TIME, train_time)


    def get_num_byz_clients(self):
        num_clients = self.conf.data.num_of_clients
        byz_ratio: float = self.conf.attacker.byz_ratio
        num_byz = ceil(num_clients * byz_ratio)
        print(f"num_clients: {num_clients}, num_byz: {num_byz}")
        assert 0 <= num_byz <= num_clients, f"invalid byz_ratio {byz_ratio}"
        return num_byz

    def get_byz_clients(self, clients: list[CustomizedClient]):
        num_byz = self.get_num_byz_clients()

        byz_clients = clients[:num_byz]
        for client in byz_clients:
            client.set_byz()

        return byz_clients


    def set_attacker(self, attacker):
        self.attacker = attacker

    def aggregation(self):
        """Aggregate training updates from clients.
        Server aggregates trained models from clients via federated averaging.
        """
        uploaded_content = self.get_client_uploads()
        models = list(uploaded_content[MODEL].values())
        weights = list(uploaded_content[DATA_SIZE].values())
        model = self.aggregate(models, weights)
        self.set_model(model, load_dict=True)

    def aggregate(self, models, weights):

        if self.conf.server.use_gas:
            if getattr(self.conf.server, 'use_gas_mr', False):
                print("Using  GAS-MR")
                agg_model = self.use_gas_mr(models, weights)
            else:
                print("Using GAS")
                agg_model = self.gas_aggregate(models, weights)

        else:
            flat_models, struct = flatten_models(models)
            base_agg = agg_funs[self.conf.server.base_agg]
            n_sel_byz = sum((1 if selected_client.is_byz else 0) for selected_client in self.selected_clients)
            knowledge = Namespace(n_byz=n_sel_byz)
            flat_agg_model = base_agg(flat_models, knowledge, self.conf)
            agg_state_dict = unflatten_tensor(flat_agg_model, struct)
            agg_model = copy.deepcopy(models[0])
            agg_model.load_state_dict(agg_state_dict)
            # flatten client models
        return agg_model


    @torch.no_grad()

    def gas_aggregate(self, models, weights):
        # flatten
        flat_models, struct = flatten_models(models)
        # splitting
        groups = self.split(flat_models)
        # identification
        base_agg = agg_funs[self.conf.server.base_agg]
        n_cl = len(flat_models)
        n_sel_byz = sum((1 if selected_client.is_byz else 0) for selected_client in self.selected_clients)
        knowledge = Namespace(n_byz=n_sel_byz)
        identification_scores = torch.zeros(n_cl)
        for group in groups:
            group_agg = base_agg(group, knowledge, self.conf)
            group_scores = (group - group_agg).square().sum(dim=-1).sqrt().cpu()
            identification_scores += group_scores

        _, cand_idxs = identification_scores.topk(k=n_cl - n_sel_byz, largest=False)


        # aggregation
        flat_agg_model = flat_models[cand_idxs].mean(dim=0)
        # unflatten
        agg_state_dict = unflatten_tensor(flat_agg_model, struct)
        agg_model = copy.deepcopy(models[0])
        agg_model.load_state_dict(agg_state_dict)

        return agg_model


    @torch.no_grad()
    def use_gas_mr(self, models, weights):
        flat_models, struct = flatten_models(models)
        n_cl = flat_models.size(0)

        groups = self.split(flat_models)
        n_sel_byz = sum(c.is_byz for c in self.selected_clients)
        identification_scores = torch.zeros(n_cl)
        for group in groups:
            ref_mean = group.mean(dim=0)
            ref_median = group.median(dim=0).values
            n_client = group.size(0)
            k = max(1, int(0.1 * n_client))
            k = min(k, (n_client - 1) // 2)
            sorted_group, _ = group.sort(dim=0)
            ref_trim = sorted_group[k:-k].mean(dim=0)
            d_mean = (group - ref_mean).norm(dim=1)
            d_median = (group - ref_median).norm(dim=1)
            d_trim = (group - ref_trim).norm(dim=1)

            # cross-reference distance disagreement
            group_scores = torch.stack(
                [
                    (d_mean - d_median).abs(),
                    (d_mean - d_trim).abs(),
                    (d_trim - d_median).abs(),
                ],
                dim=0
            ).max(dim=0).values

            identification_scores += group_scores
        _, cand_idxs = identification_scores.topk(k=n_cl - n_sel_byz, largest=False)

        flat_agg_model = flat_models[cand_idxs].mean(dim=0)
        # unflatten
        agg_state_dict = unflatten_tensor(flat_agg_model, struct)
        agg_model = copy.deepcopy(models[0])
        agg_model.load_state_dict(agg_state_dict)

        return agg_model

    # @torch.no_grad()
    def split(self, flat_models):
        d = flat_models.shape[1]
        shuffled_dims = torch.randperm(d).to(flat_models.device)
        p = self.conf.server.gas_p
        partition = torch.chunk(shuffled_dims, chunks=p)
        groups = [flat_models[:, partition_i] for partition_i in partition]
        return groups

