import numpy as np
import torch
from utils import Register

agg_funs = Register()

@agg_funs.register('median')
@torch.no_grad()
def agg_median(tensor: torch.Tensor, knowledge, conf):
    return tensor.median(dim=0)[0]

@agg_funs.register('mean')
@torch.no_grad()
def agg_mean(tensor: torch.Tensor, knowledge, conf):
    """
    tensor: shape [n_client, d]
    return: shape [d]
    """
    return tensor.mean(dim=0)


@agg_funs.register('trimmean')
@torch.no_grad()
def agg_trimmean(tensor: torch.Tensor, knowledge, conf):
    """
    Coordinate-wise trimmed mean
    """
    n_client = tensor.size(0)

    # trim ratio, e.g. 0.1
    # trim_ratio = getattr(conf, "trim_ratio", 0.1)
    trim_ratio =  0.1

    k = int(trim_ratio * n_client)
    k = min(k, (n_client - 1) // 2)

    if k <= 0:
        return tensor.mean(dim=0)

    # sort along client dimension
    sorted_tensor, _ = tensor.sort(dim=0)

    # remove top-k and bottom-k
    trimmed = sorted_tensor[k : n_client - k]

    return trimmed.mean(dim=0)


@agg_funs.register('rbtm')
@torch.no_grad()
def agg_rbrm(tensor: torch.Tensor, knowledge, conf):
    n_cl = len(tensor)
    n_byz = knowledge.n_byz
    n_byz = min(n_byz, (n_cl - 1) // 2)
    if n_byz == 0:
        agg_tensor = tensor.mean(dim=0)
    else:
        sorted_tensor, _ = tensor.sort(dim=0)
        agg_tensor = sorted_tensor[n_byz:-n_byz].mean(dim=0)
    return agg_tensor


@agg_funs.register('krum')
@torch.no_grad()
def agg_krum(tensor: torch.Tensor, knowledge, conf):
    n_cl = len(tensor)
    n_byz = min(knowledge.n_byz, (n_cl - 3) // 2)

    squared_dists = torch.cdist(tensor, tensor).square()
    topk_dists, _ = squared_dists.topk(k=n_cl - n_byz -1, dim=-1, largest=False, sorted=False)    
    scores = topk_dists.sum(dim=-1)
    _, candidate_idxs = scores.topk(k=n_cl - n_byz, dim=-1, largest=False)

    agg_tensor = tensor[candidate_idxs].mean(dim=0)


    return agg_tensor

@agg_funs.register('bulyan')
@torch.no_grad()
def agg_bulyan(tensor: torch.Tensor, knowledge, conf):
    all_updates = tensor
    n_attackers = knowledge.n_byz
    nusers = all_updates.shape[0]
    bulyan_cluster = []
    candidate_indices = []
    remaining_updates = all_updates
    all_indices = np.arange(len(all_updates))

    while len(bulyan_cluster) < (nusers - 2 * n_attackers):
        torch.cuda.empty_cache()
        distances = []
        for update in remaining_updates:
            distance = []
            for update_ in remaining_updates:
                distance.append(torch.norm((update - update_)) ** 2)
            distance = torch.Tensor(distance).float()
            distances = distance[None, :] if not len(distances) else torch.cat((distances, distance[None, :]), 0)

        distances = torch.sort(distances, dim=1)[0]

        scores = torch.sum(distances[:, :len(remaining_updates) - 2 - n_attackers], dim=1)
        indices = torch.argsort(scores)[:len(remaining_updates) - 2 - n_attackers]
        if not len(indices):
            break
        candidate_indices.append(all_indices[indices[0].cpu().numpy()])
        all_indices = np.delete(all_indices, indices[0].cpu().numpy())
        bulyan_cluster = remaining_updates[indices[0]][None, :] if not len(bulyan_cluster) else torch.cat((bulyan_cluster, remaining_updates[indices[0]][None, :]), 0)
        remaining_updates = torch.cat((remaining_updates[:indices[0]], remaining_updates[indices[0] + 1:]), 0)


    if isinstance(bulyan_cluster, list):
        if len(bulyan_cluster) > 0:
            bulyan_cluster = torch.stack(bulyan_cluster, dim=0)
        else:

            return tensor.mean(dim=0)

    n, d = bulyan_cluster.shape
    param_med = torch.median(bulyan_cluster, dim=0)[0]
    sort_idx = torch.argsort(torch.abs(bulyan_cluster - param_med), dim=0)
    sorted_params = bulyan_cluster[sort_idx, torch.arange(d)[None, :]]


    keep_count = max(1, min(n, n - 2 * n_attackers))
    agg_tensor = torch.mean(sorted_params[:keep_count], dim=0)
    return agg_tensor


@agg_funs.register('multi_krum')
@torch.no_grad()
def agg_multi_krum(tensor: torch.Tensor, knowledge, conf):
    """
    实现 Multi-Krum 算法，一种用于联邦学习中的鲁棒聚合算法
    """
    all_updates = tensor
    n_attackers = knowledge.n_byz


    candidates = []
    candidate_indices = []
    remaining_updates = all_updates
    all_indices = np.arange(len(all_updates))

    while len(remaining_updates) > 2 * n_attackers + 2:
        torch.cuda.empty_cache()
        distances = []
        for update in remaining_updates:
            distance = []
            for update_ in remaining_updates:
                distance.append(torch.norm((update - update_)) ** 2)
            distance = torch.Tensor(distance).float()
            distances = distance[None, :] if not len(distances) else torch.cat((distances, distance[None, :]), 0)

        distances = torch.sort(distances, dim=1)[0]
        scores = torch.sum(distances[:, :len(remaining_updates) - 2 - n_attackers], dim=1)
        indices = torch.argsort(scores)[:len(remaining_updates) - 2 - n_attackers]

        candidate_indices.append(all_indices[indices[0].cpu().numpy()])
        all_indices = np.delete(all_indices, indices[0].cpu().numpy())
        candidates = remaining_updates[indices[0]][None, :] if not len(candidates) else torch.cat((candidates, remaining_updates[indices[0]][None, :]), 0)
        remaining_updates = torch.cat((remaining_updates[:indices[0]], remaining_updates[indices[0] + 1:]), 0)

    if len(candidates) > 0:
        candidates_tensor = torch.stack(candidates, dim=0) if isinstance(candidates, list) else candidates
        agg_tensor = torch.mean(candidates_tensor, dim=0)
    else:
        agg_tensor = torch.mean(all_updates, dim=0)

    return agg_tensor
